# Dr. Sumreen Asim — Website Aesthetic

## Mood

Warm, playful, and scholarly. The page reads like a light lavender morning over a Monet-style pond: soft painted texture, a small blue cartoon butterfly that guides the visitor down the page, a cheerful sloth hanging from a branch, and a coffee-ring stain as a nod to her love of coffee. The whimsy stays in the margins so the content remains easy to read.

## Color palette

The base is purple (paper and ink). The accents are teal and amber, so the page doesn't rely on shades of purple alone.

| Role | Light mode | Dark mode | Used for |
|---|---|---|---|
| Paper (background) | `#F5F1FC` | `#1A1430` | Page background |
| Surface | `#FFFFFF` | `#241C40` | Cards, photo frame, search box |
| Ink | `#2B2147` | `#EDE8FA` | Body text, headings, solid button, contact band |
| Muted | `#675C85` | `#B4A9D2` | Secondary text, captions, nav links |
| Teal accent | `#0E7C7B` | `#5ED3CB` | Links, publication years, timeline dots, card lines |
| Amber (text) | `#8F5A08` | `#F2B84B` | Topic tags |
| Amber (display) | `#B5730E` | `#F2B84B` | Citation numbers, "$1.4M+", research highlight bars |
| Line | `#DDD4F0` | `#3A3060` | Dividers and borders |
| Coffee ring | `#9B7A66` | `#C9A48E` | Coffee-stain graphic by the portrait |
| Trail | `#3F7FE0` | `#7FB2FF` | Butterfly's dotted guide path |

Butterfly colors: wings graded from `#8FDBFF` to `#2F6BDB`, outlines and body `#1B2A5C`, white wing spots, and a yellow eyespot (`#FFD66B`).

Sloth colors: fur `#A9835C`, limbs `#94704B`, belly `#C7A57C`, face `#F1E2C8`, eye patches `#5A3E2A`, cheeks `#F2A7A0`. The branch is `#7A5634` with green leaves (`#4FAE7E`, `#6CC48F`).

## Typography

- **Display font:** Bricolage Grotesque (weights 400, 600, 800), used for the name, section headings, navigation, buttons, and labels. Fallbacks: Avenir Next, Segoe UI, system sans-serif.
- **Body font:** Source Serif 4, used for paragraphs and publication details. Fallbacks: Georgia, Times New Roman.
- **Name at the top:** very large (up to about 104px), extra bold, with slightly tightened letter spacing.
- **Body text:** 18px with generous line height (1.7), kept to a comfortable reading width.

## Layout

- The content column is at most about 1,090px wide and centered.
- **Top:** a two-column header, with the name, title, intro, and buttons on the left and a tilted polaroid-style portrait on the right. On phones, the portrait moves below the text.
- **Sections:** each has its heading in a narrow left column and content on the right, with thin dividers between sections. On phones, the columns stack.
- **Navigation:** a sticky top bar with a frosted, see-through background.
- **Contact:** a dark plum band with large text and light-colored links.

## Background

- A soft impressionist texture of short horizontal brushstrokes in pale lavender and sky blue, evoking Monet's water paintings without copying any of them.
- It stays fixed while the page scrolls, under a light lavender wash that keeps it low-contrast.
- A large, faint copy of the cartoon butterfly sits behind the name at the top.

## Signature details

**Guide butterfly**
- A small blue cartoon butterfly flies along a dotted path that weaves between the left and right edges of the page, stopping by each section heading.
- It stays level with the upper part of the screen as you scroll and turns to face the direction it's flying.
- The part of the trail you've already passed is darker, and the path ahead is faint.
- It flaps only while you scroll. When you stop, it hovers, bobs gently, and slowly opens and closes its wings.
- Kept small (about 52px, 40px on phones), behind the text, and never blocking clicks.

**Sloth**
- A cartoon sloth hangs from a leafy branch at the right edge of the About section.
- When the section scrolls into view, the branch slides in from the edge and the sloth swings down into place with a little bounce.
- It then sways slowly and blinks now and then, and it replays if you scroll away and come back.

**Portrait card**
- A white polaroid frame tilted slightly, with the caption "Fueled by coffee and a good laugh."
- A coffee-ring stain overlaps its corner and fades in when the page loads.

**Other details**
- **Timeline:** Experience and Education use a vertical line with hollow teal dots and the dates above each entry.
- **Publications:** three highlight cards with large amber citation counts, then a search box and a Newest / Most cited toggle. Her name is bold in every author list.
- **Photo gallery:** a grid of rounded photos, with one tall photo on the left and captions over a dark plum fade at the bottom of each.

## Motion and accessibility

- All motion is gentle and slow except the butterfly's quick flapping while you scroll.
- Visitors who turn on the reduced-motion setting see no butterfly or trail, and the sloth appears without animating.
- The site has full light and dark modes.
- Keyboard focus shows a clear teal outline.
- Decorative graphics are hidden from screen readers, and all photos have descriptions.
