# Dr. Sumreen Asim — Website Content

All text and information shown on the site, in page order.

## Header

**Sumreen Asim, Ph.D.**
Professor of Science and Technology Education
Elementary Education Program, Indiana University Southeast

More than two decades of helping teachers bring inquiry, technology, and culturally responsive practice into STEM classrooms.

Buttons: Email Dr. Asim (sasim@iu.edu) · See her research

Portrait caption: Fueled by coffee and a good laugh.

## About

Dr. Asim teaches STEM courses to undergraduate and graduate students at IU Southeast. The daughter of immigrants from Pakistan, she grew up on Long Island and began her career as an educator in New York City, teaching in both private and public schools.

While earning her doctorate at the University of North Texas, she worked with the UTeach program. Today she focuses on sharing, learning, and growing alongside fellow educators, and on helping them put inquiry-based instruction into practice. She is always ready to share a good laugh and leave people smiling.

## Teaching

She teaches science and technology courses at the undergraduate and graduate level, preparing future elementary teachers to lead hands-on STEM learning.

**Teaching interests:** Science and STEM education; informal science education; educational technology; culturally responsive teaching; professional development.

**Honors**
- IUS Trustees Award
- IUS Faculty Innovator Award
- IUS Distinguished Teaching Award
- IUS Distinguished Research and Creativity Award
- Innovative College Science Teaching, Hoosier Association of Science Teachers, Inc.
- STEM Trailblazer, STEM Crew Magazine, 2025
- SIG-TACTL Best Paper Award, American Educational Research Association, 2023
- Inductee, IU Faculty Academy on Excellence in Teaching (FACET), Class of 2023

## Research

Her work centers on STEM teacher preparation, using qualitative and mixed-methods studies alongside practitioner pieces. Her interests span collaborative STEM education, culturally responsive teaching, and educational technology, and she has published widely in journals, books, and conference proceedings.

- **$1.4M+** secured in grants as principal investigator, co-principal investigator, or project director.
- **NSF principal investigator:** Collaborative Research: Integrated STEM self-efficacy among elementary preservice teachers, including Noyce Scholars.
- **Co-editor, CITE Science:** Contemporary Issues in Technology and Teacher Education, science section (https://citejournal.org/category/science/page/2/).
- **Science Curator, CAD library.** Also connected with the Critical Theory in Teaching and Technology SIG (https://site.aace.org/sigs/critical-theory-in-teaching-and-technology-sig/).

**Presented at:** HASTI, KySTE, NSTA, AERA, ASTE, NARST, SITE, SSMA, and ISTE, at regional, national, and international conferences.

## Publications

45 articles, chapters, books, and proceedings, cited 293 times according to Google Scholar.

**Most cited**
1. Differentiating instruction for middle school students in virtual learning environments. *Delta Kappa Gamma Bulletin*, 2020. 64 citations.
2. Student teachers' images of science instruction in informal settings. *Journal of Science Teacher Education*, 2018. 49 citations.
3. Confronting tools of the oppressor: Framing just technology integration. *CITE Journal*, 2022. 48 citations.

**Full list**

### 2026

- Integrating augmented reality and artificial intelligence to enhance elementary teacher candidates' STEM teaching. **S Asim**. *EdMedia, 538–542*.
- Leveraging augmented reality (AR). **S Asim**, JD Mendez. *Quick Hits for Creativity in the Classroom, Indiana University Press*.
- Quick Hits for Creativity in the Classroom: Successful Strategies from Award-Winning Teachers. **S Asim**, C Barwick, K Behling, AL Bhandary, K Blewett, M Bryant, et al.. *Indiana University Press*.

### 2025

- What is STEM? Preservice elementary teachers' conceptions of integrated STEM education. JR Wieselmann, D Menon, BC Price, A Johnson, **S Asim**, S Haines, et al.. *Teaching and Teacher Education 165, 105108*. Cited 16.
- Preservice elementary teachers' integrated STEM teaching self-efficacy: Contributing sources within STEM education courses. D Menon, JR Wieselmann, S Haines, **S Asim**, A Koch, D Cox. *AERA Open 11*. Cited 11.
- Digital ethics and equity in K-12 blended and online learning. J Darling-Aduana, MK Heath, A Stewart, S Viano, **S Asim**, A Garcia, et al.. *Handbook of Children and Screens*. Cited 7.
- Collaborative global learning within an integrated STEM professional development using children's literature. **S Asim**, S Haines, J Wieselmann, D Menon. *School Science and Mathematics 125(6), 644–652*. Cited 2.
- Applying a technology integration model to guide literacy lesson planning: A focus on teaching critical literacy skills using multicultural literature and digital tools. KS Howe, **S Asim**, R Christensen. *Literacy Practice & Research 49(2)*. Cited 1.
- Supporting teacher self-efficacy for integrated STEM instruction: Insights from a multi-year project. J Wieselmann, **S Asim**, D Menon, S Haines. *Innovations in Science Teacher Education 10(3)*.

### 2024

- A meta-synthesis of the literature on science & engineering teaching self-efficacy: Current gaps and future research directions. D Menon, JR Wieselmann, S Haines, **S Asim**. *Journal of Science Teacher Education 35(5), 480–503*. Cited 26.
- Teaching justice-oriented technology pedagogy: An inquiry-based approach for teacher educators to critically address edtech. **S Asim**, J Henderson, M Heath, N Milman. *Contemporary Issues in Technology and Teacher Education 24(4), 612–632*. Cited 3.
- Female pre-service elementary teachers' conceptualizations of engineers and engineering: A critical consciousness perspective. K Subramaniam, N Khan, CS Long, MR Librea-Carden, **S Asim**. *Journal of Science Teacher Education 35(6), 594–613*. Cited 1.
- First glances toward the 2024 total solar eclipse: Looking down with pinhole projectors can engage young scientists as much as donning eclipse glasses to look up. **S Asim**, G Knezek, R Christensen, T Tyler-Wood. *Contemporary Issues in Technology and Teacher Education 24(1), 1–10*. Cited 1.
- Bookending STEM lessons: Co-teaching with an education librarian for elementary picture-perfect success. **S Asim**, M Hughes. *Science and Children 61(1), 89–94*. Cited 1.
- Integrated STEM professional development: Utilizing best practices in an online format. **S Asim**, A Johnson, D Menon, J Wieselmann, S Haines. *Filodiritto Publisher*.
- Researching teacher self-efficacy: Linking self-efficacy to teacher effectiveness, persistence and retention. S Haines, D Menon, JR Wieselmann, **S Asim**.

### 2023

- "PD in PJs": Building a sustainable, collaborative professional development approach to address teachers' affective and technological needs. **S Asim**, L Hoffman, S Ramachandran, A Zollman, K Book, B Stewart, et al.. *SRATE Journal 32(1)*. Cited 6.
- Reframing elementary science methods courses using literature to bring in a global perspective. **S Asim**, J McDonald. *Internationalizing Rural Science Teacher Preparation*. Cited 4.
- Elementary science teacher educators learning together: Catalyzing change with educative curriculum materials and vignette writing. **S Asim**, J Davis, M Kinskey, H Lavender, J Murray, A Obery, et al.. *Innovations in Science Teacher Education 8(3)*. Cited 3.
- Metadata standards for educational objects. G Bull, S Greenstein, J Ellis, **S Asim**, R Novitski, E Whitewolf, S Lake. *Contemporary Issues in Technology and Teacher Education 23(3), 508–517*. Cited 1.
- Modeling innovative technology use in teacher education and professional development, part 2. Y Jin, M McVey, R Christensen, **S Asim**, K Howe, J Cheon, D Rutledge, et al.. *SITE International Conference*. Cited 1.
- Teaching the E in STEM: A synthesis of the engineering teaching self-efficacy literature. S Haines, D Menon, J Wieselmann, **S Asim**. *Association for Science Teacher Education*. Cited 1.
- Why isn't technology and teacher education talking more about justice and technology?. MK Heath, **S Asim**, N Milman, J Henderson. *Civics of Technology (blog)*. Cited 1.
- NTLS/SITE Emerging Leaders Program: A path to more inclusive leadership. **S Asim**, JD Cohen, S Dunn, Y Jin, SS Budhai. *Contemporary Issues in Technology and Teacher Education 23(4), 552–557*.
- Insights from a computer science K-6 professional development: What our elementary teachers need. S Hettiarachchi, **S Asim**. *SITE International Conference*.
- Science education in the digital age: Theoretical and practical suggestions. D Slykhuis, **S Asim**, J Ellis, J Trumble. *SITE International Conference*.

### 2022

- Confronting tools of the oppressor: Framing just technology integration in educational technology and teacher education. M Heath, **S Asim**, N Milman, J Henderson. *Contemporary Issues in Technology and Teacher Education 22(4), 754–777*. Cited 48.
- Three domains for technology integration in science teacher education. **S Asim**, J Ellis, J Trumble, D Slykhuis. *Contemporary Issues in Technology and Teacher Education (Science)*. Cited 14.
- Confronting tools of the oppressor: Exploring justice in educational technology and teacher education. M Heath, **S Asim**, N Milman, J Henderson. *Contemporary Issues in Technology and Teacher Education (General)*.

### 2021

- Lessons learned from facilitating inquiry-based science online teaching: Challenges and opportunities to enhance student experiences. **S Asim**, J Hollenbeck. *Science Education during the COVID-19 Pandemic, 5–34*. Cited 3.
- Exploring the complexities of just technology integration: The power, privilege, and prejudice of technology. M Heath, **S Asim**, N Milman, J Henderson. *SITE International Conference*. Cited 2.
- Touchstone: Activating 3D artifacts in the classroom. CB Griggs, **S Asim**, ME Hughes. *Oregon Journal of the Social Studies 9(1), 61–72*.

### 2020

- Differentiating instruction for middle school students in virtual learning environments. **S Asim**, PJ Ponners, C Bartlett, A Parker, R Star. *Delta Kappa Gamma Bulletin 86(3)*. Cited 64.
- It's about how to pivot: Teacher educators, teacher candidates and Twitter. **S Asim**, S Poyo, S Fecich. *Teaching, Technology, and Teacher Education during the COVID-19 Pandemic*. Cited 9.
- How can we advance just technology integration?. **S Asim**, MK Heath, DG Krutka, J Lee, NB Milman, J Henderson. *SITE Interactive Conference, 102–105*. Cited 2.
- "Hello! Is anybody out there?" Amplifying a social media network within a science methods course during COVID-19. **S Asim**. *The Hoosier Science Teacher 43(2), 1–7*. Cited 1.

### 2019

- My students rather use technology anyways! Increasing digital pedagogy of teacher candidates. **S Asim**. *ICERI2019 Proceedings, 8780–8783*.
- Emphasizing the "T" in STEAM in science instructional practices of elementary teacher candidates: Developing 21st century practice. **S Asim**. *ICERI2019 Proceedings, 8775–8779*.

### 2018

- Student teachers' images of science instruction in informal settings: A focus on field trip pedagogy. K Subramaniam, **S Asim**, EY Lee, Y Koo. *Journal of Science Teacher Education*. Cited 49.
- Exploring the changes of elementary teacher candidates' beliefs enrolled in a technology infused science methods course. **S Asim**. *SITE International Conference*. Cited 4.

### 2016

- Beyond the classroom walls: Technology infusion advancing science education. P Ponners, **S Asim**. *Delta Kappa Gamma Bulletin 83(1)*. Cited 6.
- How science teacher educators of color conceptualize and operationalize their pedagogy in science methods courses. K Subramaniam, **S Asim**, EY Lee, KS Rideaux. *Enhancing Professional Knowledge of Pre-Service Science Teacher Education*. Cited 3.
- Teaching beyond the walls: A mixed method study of prospective elementary teachers' belief systems about science instruction. **S Asim**. *Doctoral dissertation, University of North Texas*. Cited 1.

### 2015

- Using Wordles as the visual data to explore prospective elementary teachers' conceptions of informal science education. **S Asim**. *SITE International Conference*. Cited 1.

### 2014

- STEM transmedia book. P Ponners, **S Asim**, T Tyler-Wood. *SITE International Conference*.

## Photo gallery: Around campus and beyond

- Presenting at IU Southeast
- Ph.D., University of North Texas
- A welcome at the School of Education
- Receiving an Indiana University Southeast award

## Experience

### Indiana University Southeast, New Albany, IN
- **Professor**, 2024 – present
- **IUS Administrative Faculty Fellow**, 2025. Built innovation, programming, and outreach with community stakeholders, including industry partners.
- **Associate Professor**, 2022 – 2024
- **Assistant Professor**, 2016 – 2022. Taught science methods, technology integration, and math assessment; supervised clinical placements and advised students.

### Service and consulting
- **Advisory Board Member**, Wilson Education Service Center, 2024 – present
- **Educational Consultant, NASA GRC Engineering Design Challenge**, Guardians of Honor, LLC, 2024 – 2025. Led NASA engineering design challenges for out-of-school educators across several states through the 21st CCLC program.
- **Subject Matter Expert**, Central Indiana Educational Service Center, 2023 – 2024. Future-Focused Learning Series on STEM education and Universal Supports for All Learners.

### Earlier career
- **Adjunct Faculty and Graduate Teaching Assistant**, University of North Texas, 2012 – 2016. Taught science methods, co-taught math methods and Professional Issues in Secondary Education, and worked with preservice middle and high school teachers at a UTeach replication site.
- **Certified Speaker and Board Member**, Islamic Speakers Bureau, DFW, 2011 – 2013. Presented to educators on understanding Muslim students and building inclusive classrooms.
- **Lecturer**, University of Phoenix, 2005 – 2006. Environmental studies.
- **Adjunct Lecturer**, City University of New York, 2003
- **Science Cluster Teacher**, NYC Department of Education, 2000 – 2002. Taught K–5 science with SCIS kits.

## Education and credentials

- **B.A., Psychology**, Brooklyn College, 1993 – 1997
- **Master's, Elementary Education and Teaching**, Long Island University (Southampton College), 1997 – 1999
- **M.S., Science and Environmental Science Education**, Brooklyn College, 2001 – 2003
- **Ph.D., Curriculum and Instruction**, University of North Texas, 2009 – 2016. Teaching Fellow; Kappa Delta Pi.
- **Graduate Certificate in Business Management**, IU Kelley School of Business, 2025 – 2026

**Certifications**
- New York State teaching certification: Elementary N–6, General Science 7–8, Biology 9–12
- Apple Learning Coach, 2022; Apple Teacher, 2019
- Quality Matters Peer Reviewer, 2024; Applying the QM Rubric, 2019
- Techbridge Girls: Cultivating STEM Equity in Educational Systems, 2025
- Adobe Education Institute, 2023
- Mental Health First Aid, National Council for Mental Wellbeing, 2022

## Contact

**Let's talk STEM teaching.**

- Email: sasim@iu.edu
- Office: LF-247, IU Southeast
- LinkedIn: https://www.linkedin.com/in/drsumreenstem/
- University profile: https://profiles.iu.edu/southeast/asim-sumreen.html

Footer: © 2026 Sumreen Asim
